# Muninn — DFIR Console

Consola forense (DFIR) de una sola página: análisis de logs y artefactos NTFS, correlación
visual de la cadena de ataque, mapeo a MITRE ATT&CK y **análisis asistido por IA local (Ollama)
con streaming en tiempo real**. Todo en un único `.html` autocontenido, estética glassmorfismo
oscuro, con la barra de navegación a la derecha e iconos SVG (cero emojis).

Es el **frontend de referencia para tu suite Muninn DFIR** (FastAPI + custody ledger + YARA +
Volatility3 + timeline correlator). Corre en el navegador contra un caso de ejemplo embebido y,
opcionalmente, se conecta a tu backend real.

> **Cambiar el nombre** (de "Nogoda" ya pasó a "Muninn"): edita dos sitios en el HTML → el
> `<title>` y el `<h1 id="brandName">`. Un cambio, dos líneas.

---

## Cómo se usa

1. Abre `muninn-dfir-console.html` con doble clic (Chrome/Edge/Firefox). Funciona 100% offline.
2. Navega con la barra derecha o con las teclas **1–8**.
3. Pulsa **Analyze evidence** en *AI Analyst* (o **Generate AI Report** en la cabecera) para el
   informe con IA. Sin Ollama levantado, usa un análisis integrado (demo) — la consola nunca se rompe.
4. Exporta desde *Reports*: **PDF** (diálogo de impresión → guardar como PDF), **Markdown**, o **IOCs en JSON**.

### Conectar tu Ollama (IA real, no demo)
El navegador solo puede llamar a `localhost:11434` si permites el origen. Levanta Ollama así:

```bash
# Permite que el navegador (incluido file://) hable con el daemon
OLLAMA_ORIGINS=* ollama serve
ollama pull llama3.1:8b          # o mistral, qwen2.5, codellama…
```

Luego, en *Settings* → **Test connection**. Si responde, verás tus modelos instalados y el análisis
se **streamea token a token desde tu modelo**. Endpoint y modelo son configurables (persisten en la sesión).

> Si abres el archivo directamente (`file://`) y tu navegador es estricto con CORS/mixed-content,
> sírvelo en local: `python3 -m http.server` y entra por `http://localhost:8000`.

### Conectar tu backend Muninn (opcional)
En *Settings* → **Muninn Backend** apunta a tu API FastAPI (por defecto `http://localhost:8000`)
para cargar casos reales en lugar del de ejemplo.

---

## Vistas

| Vista | Qué hace |
|-------|----------|
| **Dashboard** | KPIs del caso, timeline forense en vivo, donut de severidad, actividad de artefactos 24h, resumen ejecutivo IA. |
| **Event Logs** | Tabla de eventos (Security/Sysmon/PowerShell/Defender) con búsqueda, filtro por severidad, orden por columna y **detalle expandible** por fila (metadatos + ATT&CK). |
| **MFT / NTFS** | Registros `$MFT` con comparación **`$STANDARD_INFO` vs `$FILE_NAME`**; detecta **timestomp** (backdating), ADS/MOTW y ficheros a 0 bytes (destrucción de datos). |
| **Timeline** | Super-timeline unificada y filtrable por severidad, orden cronológico inverso. |
| **Correlation** | **El diferenciador.** Reconstruye la kill-chain cruzando artefactos por PID, ruta y ventanas de 90s; 7 fases, badges ATT&CK y las fuentes que respaldan cada fase. |
| **AI Analyst** | Prompt DFIR estructurado → Ollama (`/api/chat`, `stream:true`). Análisis con secciones (Summary / Attack Chain / Indicators / Recommended Actions) y preguntas de seguimiento. |
| **Reports** | Informe ejecutivo listo para analista + tabla de IOCs (copiar individual/todos) + cobertura ATT&CK. Export **PDF / Markdown / JSON**. |
| **Settings** | Endpoint y modelo de Ollama, test de conexión con listado de modelos, URL del backend Muninn. |

**Caso de ejemplo** (`MUN-2026-0417`, host `FIN-WKS-07`): intrusión LOLBin coherente y cruzada entre
las 4 fuentes — USB → PowerShell ofuscado → C2 `185.220.101.47` → persistencia (Run key + servicio) →
timestomp + borrado de logs → destrucción de 847 ficheros + borrado de shadow copies → movimiento lateral.

---

## Qué es real y qué es maqueta (honesto)

- **Real:** el motor de correlación, la detección de timestomp ($SI vs $FN), el filtrado/orden/búsqueda,
  la extracción de IOCs, la **exportación (PDF/MD/JSON)** y la **integración con Ollama por streaming**.
- **Maqueta:** los datos del caso van embebidos y el "parseo" al importar evidencia está simulado
  (drag & drop funcional, ingesta demo). Ese es el punto donde enchufas tu backend Muninn o los
  parsers nativos.

---

## Arquitectura interna (un solo archivo)

- **Sin dependencias, sin build, sin `localStorage`** (para que funcione igual como artifact o descargado).
- `ICONS` — set único de iconos SVG stroke-based, reutilizado en toda la app (nada de emojis).
- **Router** ligero: `RENDERERS[view].html()` + `.wire()`; `navigate(id)` pinta y cablea.
- **Capa IA:** `ollamaReachable()`, `ollamaChat()` (parseo NDJSON en streaming), `buildDfirMessages()`
  (system prompt DFIR + dossier de evidencia), `demoAnalysis()` (fallback), `mdToHtml()` (render seguro: escapa y luego formatea).
- **Datos** normalizados: `EVENTS`, `MFT`, `REGISTRY`, `IOCS`, `CHAIN`, `ATTACK` (catálogo de técnicas).

### Tokens de diseño
```
--bg-deep:#0a0e1a  --bg-panel:rgba(16,22,40,.55)  --glass-border:rgba(255,255,255,.08)
--accent-cyan:#00d4ff  --accent-blue:#3b82f6  --accent-purple:#8b5cf6
--accent-green:#22c55e  --accent-orange:#f59e0b  --accent-red:#ef4444
Inter (UI) · JetBrains Mono (datos forenses)
```

### Atajos
`1`–`8` cambian de vista · `Esc` cierra el modal de importar.

---

## Del prototipo web a tu app nativa Windows (WPF/.NET 9)

Este HTML es la **especificación visual y funcional** del cliente nativo. Mapeo directo:

| Módulo del HTML | Equivalente nativo (C#) |
|-----------------|--------------------------|
| `RENDERERS.events` + tabla | `EvtxParser.cs` (`EventLogReader`) → `DashboardView.xaml` (LiveCharts2) |
| `RENDERERS.mft` + timestomp | `MftParser.cs` (P/Invoke `FSCTL_GET_NTFS_FILE_RECORD`) |
| `REGISTRY` | `RegistryHiveParser.cs` (hives offline SAM/SYSTEM/SOFTWARE) |
| Timeline / USN | `UsnJournalReader.cs` (`ReadUsnJournal`) |
| `RENDERERS.correlation` | `ArtifactCorrelator.cs` (cruce por PID/path/timestamp) |
| Capa IA (`ollamaChat`) | `OllamaClient.cs` + `PromptBuilder.cs` + `ResponseParser.cs` |
| `reportMarkdown()` / export | `ReportGenerator.cs` (PDF/HTML) + `IocExtractor.cs` |
| Glassmorphism (CSS) | XAML `AcrylicBrush` / `MicaBackdrop` (Win11 nativo) |
| `SQLite` (índice) | EF Core + SQLite, `Indexer.cs` full-text |

---

## Ficheros

- `muninn-dfir-console.html` — la consola (autocontenida).
- `README.md` — este documento.

_Generado como frontend de referencia para la suite Muninn DFIR._
